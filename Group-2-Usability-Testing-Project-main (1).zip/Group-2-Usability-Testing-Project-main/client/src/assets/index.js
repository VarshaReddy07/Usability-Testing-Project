import logoDark from "./logoDark.png";
import logoLight from "./logoLight.png";
import cart from "./cart.png";
import githubLogo from "./githubLogo.png";
import googleLogo from "./googleLogo.png";
import paymentLogo from "./paymentLogo.png";

export {logoDark, logoLight, cart, githubLogo, googleLogo, paymentLogo};